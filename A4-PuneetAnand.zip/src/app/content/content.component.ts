import { Component, OnInit, Input } from '@angular/core';
import { Student } from 'src/app/myClasses/student';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  @Input() hinfo!: Student;
  ttext!: string
  element!:HTMLElement;
  smallFunction(){
    this.element = document.getElementById("woof") as HTMLElement;
    this.element.style.width="300px";
    this.element.style.height="100px";

  }
  midFunction(){
    this.element = document.getElementById("woof") as HTMLElement;
    this.element.style.width="400px";
    this.element.style.height="200px";

  }
  bigFunction(){
    this.element = document.getElementById("woof") as HTMLElement;
    this.element.style.width="600px";
    this.element.style.height="400px";

  }

  

  constructor() { }

  ngOnInit(): void {
    this.ttext = this.hinfo.scurrent;

    
  }


}
