import { Component } from '@angular/core';
import {Student} from './myClasses/student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment 4 Puneet Anand';
  bio:Student = {sid:991660474, sname: "Puneet Anand", slogin: "ananpune", shome: "Toronto", scurrent: "Toronto", spic: "assets/img/me.jpg"};
  
}
